const nextConfig = {
  experimental: { appDir: true }
};
module.exports = nextConfig;